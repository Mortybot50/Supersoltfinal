
  # SuperSolt Mockup

  This is a code bundle for SuperSolt Mockup. The original project is available at https://www.figma.com/design/qs1AWjiDT0HMdqNJXD0kfN/SuperSolt-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  