import { SidebarProvider, SidebarInset, Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarMenuSub, SidebarMenuSubItem, SidebarMenuSubButton, SidebarFooter } from "./components/ui/sidebar";
import { SalesDashboard } from "./components/SalesDashboard";
import { CoGSDashboard } from "./components/CoGSDashboard";
import { LabourDashboard } from "./components/LabourDashboard";
import { FlashPLDashboard } from "./components/FlashPLDashboard";
import { CashManagementDashboard } from "./components/CashManagementDashboard";
import superSoltLogo from 'figma:asset/d7de2f2b74fc5fa403436eebd8d150f8f233930f.png';
import { 
  ChevronRight, 
  LayoutDashboard, 
  Users, 
  Clock, 
  CreditCard, 
  Shield, 
  BarChart3, 
  Link, 
  Settings
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./components/ui/collapsible";
import { Button } from "./components/ui/button";
import { Avatar, AvatarFallback } from "./components/ui/avatar";
import { useState } from "react";

export default function App() {
  const [activeTab, setActiveTab] = useState('sales');

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const renderDashboard = () => {
    switch (activeTab) {
      case 'cogs':
        return <CoGSDashboard onTabChange={handleTabChange} activeTab={activeTab} />;
      case 'labour':
        return <LabourDashboard onTabChange={handleTabChange} activeTab={activeTab} />;
      case 'flashpl':
        return <FlashPLDashboard onTabChange={handleTabChange} activeTab={activeTab} />;
      case 'cash':
        return <CashManagementDashboard onTabChange={handleTabChange} activeTab={activeTab} />;
      case 'sales':
      default:
        return <SalesDashboard onTabChange={handleTabChange} activeTab={activeTab} />;
    }
  };

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="bg-sidebar text-sidebar-foreground border-sidebar-border">
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <img src={superSoltLogo} alt="SuperSolt" className="h-6 w-6" />
              <span className="font-semibold">SuperSolt</span>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="px-4">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton className="bg-sidebar-accent text-sidebar-foreground">
                  <div className="flex items-center gap-2">
                    <LayoutDashboard className="h-4 w-4" />
                    <span>Dashboard</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>People</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>Labour</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    <span>Payroll & Finance</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    <span>Compliance</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    <span>Reports & Insights</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>


            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-4">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton className="text-sidebar-foreground hover:bg-sidebar-accent">
                  <div className="flex items-center gap-2">
                    <Settings className="h-4 w-4" />
                    <span>Settings</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
            <div className="flex items-center gap-2 mt-4 p-2 bg-sidebar-accent rounded-lg">
              <Avatar className="h-6 w-6">
                <AvatarFallback className="bg-primary text-xs" style={{color: '#1a1d29'}}>MA</AvatarFallback>
              </Avatar>
              <span className="text-sm">Main Account</span>
              <ChevronRight className="h-4 w-4 ml-auto" />
            </div>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex-1">
          {renderDashboard()}
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}