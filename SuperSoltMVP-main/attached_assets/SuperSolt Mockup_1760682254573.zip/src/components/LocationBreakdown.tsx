import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Search } from "lucide-react";

const locationData = [
  {
    location: "Blanchardstown",
    sales: "$0",
    salesChange: "-",
    forecast: "$0",
    dineIn: "$0",
    dineInChange: "-",
    delivery: "$0",
    deliveryChange: "-",
    pickup: "$0",
    pickupChange: "-",
    orders: "0",
    ordersChange: "-",
    avgCheque: "$0",
    avgChequeChange: "-",
    dwellTime: "-"
  },
  {
    location: "Charlotte Way",
    sales: "$24,072",
    salesChange: "+2.8%",
    forecast: "$26,000",
    dineIn: "$12,705",
    dineInChange: "+8%",
    delivery: "$10,224",
    deliveryChange: "+6.4%",
    pickup: "$1,143",
    pickupChange: "+7.8%",
    orders: "1,028",
    ordersChange: "+4.6%",
    avgCheque: "$23.42",
    avgChequeChange: "+2%",
    dwellTime: "19 mins"
  },
  {
    location: "Liffey Valley",
    sales: "$28,799",
    salesChange: "+1.9%",
    forecast: "$27,600",
    dineIn: "$22,241",
    dineInChange: "+0.3%",
    delivery: "$3,035",
    deliveryChange: "+1.2%",
    pickup: "$1,523",
    pickupChange: "+6.8%",
    orders: "846",
    ordersChange: "+3.3%",
    avgCheque: "$31.31",
    avgChequeChange: "+4%",
    dwellTime: "36 mins"
  },
  {
    location: "Dundrum",
    sales: "$27,706",
    salesChange: "+0.4%",
    forecast: "$30,000",
    dineIn: "$19,138",
    dineInChange: "+1.6%",
    delivery: "$6,950",
    deliveryChange: "-3.4%",
    pickup: "$1,618",
    pickupChange: "+1.8%",
    orders: "976",
    ordersChange: "+4.1%",
    avgCheque: "$28.01",
    avgChequeChange: "+2%",
    dwellTime: "43 mins"
  },
  {
    location: "Millennium Walk",
    sales: "$32,499",
    salesChange: "+2.7%",
    forecast: "$30,900",
    dineIn: "$23,467",
    dineInChange: "+4.6%",
    delivery: "$8,143",
    deliveryChange: "+3.2%",
    pickup: "$889",
    pickupChange: "+5.3%",
    orders: "1,206",
    ordersChange: "+3.7%",
    avgCheque: "$26.74",
    avgChequeChange: "+0%",
    dwellTime: "42 mins"
  }
];

const getChangeColor = (change: string) => {
  if (change === "-") return "text-muted-foreground";
  if (change.startsWith("+")) return "text-primary";
  if (change.startsWith("-")) return "text-destructive";
  return "text-muted-foreground";
};

export function LocationBreakdown() {
  return (
    <Card className="border border-border bg-card card-glow-subtle">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-foreground">Location</span>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by location" 
              className="pl-10 bg-input border-border text-foreground placeholder-muted-foreground"
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-muted-foreground font-medium">Location</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Sales</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Forecast</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Dine-in</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Delivery</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Pick-up</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Orders</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Avg cheque size</th>
                <th className="text-center py-3 px-4 text-muted-foreground font-medium">Dwell Time</th>
              </tr>
            </thead>
            <tbody>
              {locationData.map((location, index) => (
                <tr key={index} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="py-3 px-4">
                    <span className="text-foreground font-medium">{location.location}</span>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground font-medium">{location.sales}</span>
                      <span className={`text-xs ${getChangeColor(location.salesChange)}`}>
                        {location.salesChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <span className="text-muted-foreground">{location.forecast}</span>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground">{location.dineIn}</span>
                      <span className={`text-xs ${getChangeColor(location.dineInChange)}`}>
                        {location.dineInChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground">{location.delivery}</span>
                      <span className={`text-xs ${getChangeColor(location.deliveryChange)}`}>
                        {location.deliveryChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground">{location.pickup}</span>
                      <span className={`text-xs ${getChangeColor(location.pickupChange)}`}>
                        {location.pickupChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground">{location.orders}</span>
                      <span className={`text-xs ${getChangeColor(location.ordersChange)}`}>
                        {location.ordersChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <div className="flex flex-col items-center">
                      <span className="text-foreground">{location.avgCheque}</span>
                      <span className={`text-xs ${getChangeColor(location.avgChequeChange)}`}>
                        {location.avgChequeChange}
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3 px-4">
                    <span className="text-foreground">{location.dwellTime}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}