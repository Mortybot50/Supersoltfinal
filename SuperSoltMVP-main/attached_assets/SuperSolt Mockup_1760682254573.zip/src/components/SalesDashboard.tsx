import { HorizontalMetricCard } from "./HorizontalMetricCard";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { DateSelector } from "./DateSelector";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { TrendingUp } from "lucide-react";

interface SalesDashboardProps {
  onTabChange: (tab: string) => void;
  activeTab: string;
}

const salesChartData = [
  { day: 'Mon 1', actual: 4200, forecast: 4800 },
  { day: 'Tue 2', actual: 5100, forecast: 5400 },
  { day: 'Wed 3', actual: 4800, forecast: 5100 },
  { day: 'Thu 4', actual: 6200, forecast: 6800 },
  { day: 'Fri 5', actual: 8500, forecast: 9200 },
  { day: 'Sat 6', actual: 9200, forecast: 10100 },
  { day: 'Sun 7', actual: 10800, forecast: 11200 }
];

const ordersChartData = [
  { day: 'Mon 1', actual: 152, forecast: 168 },
  { day: 'Tue 2', actual: 184, forecast: 195 },
  { day: 'Wed 3', actual: 173, forecast: 184 },
  { day: 'Thu 4', actual: 224, forecast: 245 },
  { day: 'Fri 5', actual: 306, forecast: 331 },
  { day: 'Sat 6', actual: 331, forecast: 364 },
  { day: 'Sun 7', actual: 389, forecast: 403 }
];

const productsData = [
  { name: 'Tenders with 2 Dips', value: '$13,342.33', change: '+8.1%', salesPercent: '12.95%', changePositive: true },
  { name: 'Tenders with 2 Dips', value: '$13,299.60', change: '+0.6%', salesPercent: '12.91%', changePositive: true },
  { name: 'The GOAT', value: '$8,073.33', change: '-6.8%', salesPercent: '7.83%', changePositive: false },
  { name: 'Wild Thing', value: '$6,087.33', change: '+15.7%', salesPercent: '5.91%', changePositive: true },
  { name: 'Nashville Hot Chick', value: '$5,692.00', change: '+12%', salesPercent: '5.52%', changePositive: true },
  { name: 'The OG', value: '$4,303.81', change: '+15.9%', salesPercent: '4.17%', changePositive: true },
  { name: 'Love Me Sweetie', value: '$2,883.99', change: '+6.7%', salesPercent: '4.1%', changePositive: true },
  { name: 'Regular Fries', value: '$2,883.99', change: '+19%', salesPercent: '4.1%', changePositive: true },
  { name: 'Honey Baby', value: '$2,883.99', change: '+19%', salesPercent: '4.1%', changePositive: true },
  { name: 'Tenders Double Stack', value: '$2,883.99', change: '+19%', salesPercent: '4.1%', changePositive: true },
  { name: 'Love Me Raunchy', value: '$2,883.99', change: '+19%', salesPercent: '4.1%', changePositive: true }
];

const CustomTooltip = ({ active, payload, label, viewType }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
        <p className="text-foreground font-medium mb-2">{data.day}</p>
        <div className="space-y-1">
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">{viewType === 'orders' ? 'Orders:' : 'Sales:'}</span>
            <span className="text-foreground font-medium">
              {viewType === 'orders' ? data.actual.toLocaleString() : `$${data.actual.toLocaleString()}`}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">Forecast:</span>
            <span className="text-muted-foreground">
              {viewType === 'orders' ? data.forecast.toLocaleString() : `$${data.forecast.toLocaleString()}`}
            </span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export function SalesDashboard({ onTabChange, activeTab }: SalesDashboardProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [chartView, setChartView] = useState<'sales' | 'orders'>('sales');
  
  const currentChartData = chartView === 'orders' ? ordersChartData : salesChartData;
  const totalActual = chartView === 'orders' ? '1,759' : '$48,800';
  const totalForecast = chartView === 'orders' ? '1,890' : '$52,600';
  const totalChange = chartView === 'orders' ? '-6.9%' : '-7.2%';

  return (
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex gap-4 text-sm">
            <button 
              onClick={() => onTabChange('sales')}
              className={`pb-1 ${activeTab === 'sales' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Sales
            </button>
            <button 
              onClick={() => onTabChange('cogs')}
              className={`pb-1 ${activeTab === 'cogs' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              CoGS
            </button>
            <button 
              onClick={() => onTabChange('labour')}
              className={`pb-1 ${activeTab === 'labour' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Labour
            </button>
            <button 
              onClick={() => onTabChange('flashpl')}
              className={`pb-1 ${activeTab === 'flashpl' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Flash P&L
            </button>
            <button 
              onClick={() => onTabChange('cash')}
              className={`pb-1 ${activeTab === 'cash' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Cash management
            </button>
          </div>
        </div>
        
        {/* Center - Date Selector */}
        <div className="flex-1 flex justify-center">
          <DateSelector />
        </div>
        
        {/* Right - Location Dropdown */}
        <div className="w-64 relative">
          <div className="bg-card border border-border rounded-lg">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full flex items-center justify-between p-3 hover:bg-muted/30 rounded-lg transition-colors"
            >
              <span className="text-sm text-muted-foreground">All locations</span>
              <div className="flex items-center gap-1">
                <div className="w-6 h-6 bg-muted-foreground/20 rounded-full flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">4</span>
                </div>
                <svg 
                  className={`w-4 h-4 text-muted-foreground transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </button>
          </div>
            
          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50">
              <div className="p-3">
                <div className="relative mb-3">
                  <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <input 
                    type="text" 
                    placeholder="Search" 
                    className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-sm text-foreground placeholder-muted-foreground"
                  />
                </div>
                
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground mb-2">Blanchardstown</div>
                  <button className="w-full bg-primary text-primary-foreground px-3 py-2 rounded text-sm font-medium text-left">
                    Charlotte Way
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Dundrum
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    HQ
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Liffey Valley
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Top Metric Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <HorizontalMetricCard
          title="Sales to date"
          value="$93,779"
          comparison="vs forecast"
          comparisonValue="+2.1%"
          items={[
            { label: 'Dine-in', value: '73%', color: '#8b5cf6', percentage: 73 },
            { label: 'Pick-up', value: '5%', color: '#d946ef', percentage: 5 },
            { label: 'Delivery', value: '22%', color: '#ec4899', percentage: 22 }
          ]}
        />
        
        <HorizontalMetricCard
          title="Avg cheque size"
          value="$26.43"
          comparison="vs forecast"
          comparisonValue="+6t.6%"
          items={[
            { label: 'Dine-in', value: '$27', color: '#f97316', percentage: 65 },
            { label: 'Pick-up', value: '$21', color: '#fbbf24', percentage: 50 },
            { label: 'Delivery', value: '$24.68', color: '#fb923c', percentage: 58 }
          ]}
        />
        
        <HorizontalMetricCard
          title="Dwell time"
          value="40min"
          singleBar={{ color: '#b6ff94', percentage: 60 }}
        />
      </div>

      {/* Main Content - Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column - Chart (Takes 2 columns) */}
        <div className="lg:col-span-2">
          <Card className="border border-border bg-card card-glow-subtle h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-foreground">
                {chartView === 'sales' ? 'Sales vs Forecast: 1-7 Mar' : 'Orders vs Forecast: 1-7 Mar'}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={currentChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <XAxis dataKey="day" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip viewType={chartView} />} cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }} />
                    <Bar dataKey="actual" fill="#b6fe9a" radius={[2, 2, 0, 0]} />
                    <Bar 
                      dataKey="forecast" 
                      fill="rgba(182, 254, 154, 0.15)"
                      stroke="#b6fe9a"
                      strokeWidth={1.5} 
                      radius={[2, 2, 0, 0]} 
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              {/* Tabs and Summary */}
              <div className="mt-6 space-y-4">
                <div className="flex gap-4 text-sm border-b border-border">
                  <button
                    onClick={() => setChartView('sales')}
                    className={`pb-2 transition-all ${
                      chartView === 'sales'
                        ? 'border-b-2 border-primary text-foreground'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Sales
                  </button>
                  <button
                    onClick={() => setChartView('orders')}
                    className={`pb-2 transition-all ${
                      chartView === 'orders'
                        ? 'border-b-2 border-primary text-foreground'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Orders
                  </button>
                </div>
                
                {/* Summary Metrics */}
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{chartView === 'sales' ? 'Sales' : 'Orders'}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-semibold text-foreground">{totalActual}</span>
                      <span className="text-sm text-destructive">{totalChange}</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Total {chartView === 'sales' ? 'sales' : 'orders'}</p>
                    <span className="text-lg font-semibold text-foreground">0</span>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Dine in</p>
                    <span className="text-lg font-semibold text-foreground">{chartView === 'sales' ? '$1,515' : '0'}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Products Table */}
        <div>
          <Card className="border border-border bg-card card-glow-subtle h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-foreground">Products</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col overflow-hidden">
              <div className="space-y-1 flex-1 flex flex-col">
                {/* Table Header */}
                <div className="grid grid-cols-12 gap-2 pb-2 border-b border-border text-xs text-muted-foreground">
                  <div className="col-span-5">Product Name</div>
                  <div className="col-span-4 text-right">Value</div>
                  <div className="col-span-3 text-right">% of sales</div>
                </div>
                
                {/* Table Rows */}
                <div className="space-y-1 flex-1 overflow-y-auto">
                  {productsData.map((product, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 py-2 hover:bg-muted/20 rounded transition-colors">
                      <div className="col-span-5 text-sm text-foreground truncate">{product.name}</div>
                      <div className="col-span-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <span className={`text-xs ${product.changePositive ? 'text-primary' : 'text-destructive'}`}>
                            {product.changePositive ? <TrendingUp className="h-3 w-3" /> : '↓'}
                          </span>
                          <span className={`text-xs ${product.changePositive ? 'text-primary' : 'text-destructive'}`}>
                            {product.change}
                          </span>
                          <span className="text-sm text-foreground">{product.value}</span>
                        </div>
                      </div>
                      <div className="col-span-3 text-right text-sm text-muted-foreground">{product.salesPercent}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
