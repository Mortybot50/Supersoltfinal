import { Card, CardContent } from "./ui/card";
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

interface InventoryMetricCardProps {
  title: string;
  value: string;
  subtitle?: string;
  color?: string;
  chartData?: Array<{ value: number }>;
}

export function InventoryMetricCard({ title, value, subtitle, color = "#10b981", chartData }: InventoryMetricCardProps) {
  // Default chart data if none provided
  const defaultChartData = [
    { value: 20 }, { value: 35 }, { value: 28 }, { value: 45 }, { value: 52 }, 
    { value: 38 }, { value: 65 }, { value: 48 }, { value: 70 }, { value: 55 }
  ];

  const data = chartData || defaultChartData;

  return (
    <Card className="border border-border bg-card card-glow-subtle">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-semibold mt-1 text-foreground">{value}</p>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
            )}
          </div>
          <div className="w-20 h-12">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id={`gradient-inventory-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                    <stop offset="100%" stopColor={color} stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke={color} 
                  strokeWidth={2}
                  fill={`url(#gradient-inventory-${color.replace('#', '')})`}
                  dot={false}
                  activeDot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}