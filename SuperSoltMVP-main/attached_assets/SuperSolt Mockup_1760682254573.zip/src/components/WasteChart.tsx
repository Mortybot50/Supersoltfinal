import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

const wasteChartData = [
  { day: 'Mon 22', accounted: 12, unaccounted: 8, fullDate: 'Mon 22 Apr' },
  { day: 'Tue 23', accounted: 15, unaccounted: 5, fullDate: 'Tue 23 Apr' },
  { day: 'Wed 24', accounted: 18, unaccounted: 12, fullDate: 'Wed 24 Apr' },
  { day: 'Thu 25', accounted: 22, unaccounted: 6, fullDate: 'Thu 25 Apr' },
  { day: 'Fri 26', accounted: 28, unaccounted: 15, fullDate: 'Fri 26 Apr' },
  { day: 'Sat 27', accounted: 25, unaccounted: 10, fullDate: 'Sat 27 Apr' },
  { day: 'Sun 28', accounted: 20, unaccounted: 8, fullDate: 'Sun 28 Apr' }
];

// Custom Tooltip Component for Waste Chart
const WasteTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const totalWaste = data.accounted + data.unaccounted;
    return (
      <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
        <p className="text-foreground font-medium mb-2">{data.fullDate}</p>
        <div className="space-y-1">
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">Accounted waste:</span>
            <span className="text-foreground font-medium">${data.accounted}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">Unaccounted waste:</span>
            <span className="text-destructive font-medium">${data.unaccounted}</span>
          </div>
          <div className="flex items-center justify-between gap-4 pt-1 border-t border-border">
            <span className="text-foreground text-sm font-medium">Total:</span>
            <span className="text-foreground font-medium">${totalWaste}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const wasteData = [
  { metric: 'Total Waste', accounted: '$840', unaccounted: '$320', total: '$1,160' },
  { metric: 'Food Waste', accounted: '$620', unaccounted: '$180', total: '$800' },
  { metric: 'Beverage Waste', accounted: '$120', unaccounted: '$80', total: '$200' },
  { metric: 'Packaging Waste', accounted: '$100', unaccounted: '$60', total: '$160' }
];

export function WasteChart() {
  return (
    <div className="space-y-6">
      <Card className="border border-border bg-card card-glow-subtle">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div>
              <h3 className="text-foreground">Waste 22-28 April</h3>
              <p className="text-sm text-muted-foreground mt-1">Show month</p>
            </div>
            <div className="flex gap-4 text-sm">
              <span className="border-b-2 border-primary pb-1 text-foreground">Waste</span>
              <span className="text-muted-foreground">Stock</span>
              <span className="text-muted-foreground">Orders</span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={wasteChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip content={<WasteTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }} />
                <Bar dataKey="accounted" fill="#10b981" radius={[2, 2, 0, 0]} />
                <Bar dataKey="unaccounted" fill="#ef4444" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-foreground">Waste Breakdown</h4>
              <div className="flex gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="text-foreground">Accounted</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-destructive rounded-full"></div>
                  <span className="text-foreground">Unaccounted</span>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              {wasteData.map((item, index) => (
                <div key={index} className="flex justify-between items-center py-2">
                  <span className="text-muted-foreground">{item.metric}</span>
                  <div className="flex gap-8 text-right">
                    <div className="flex gap-4">
                      <span className="font-medium text-foreground">{item.accounted}</span>
                      <span className="font-medium text-destructive">{item.unaccounted}</span>
                    </div>
                    <span className="text-muted-foreground w-20">{item.total}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}