import { DraggablePanel } from "./DraggablePanel";
import { Card, CardContent } from "./ui/card";
import { DateSelector } from "./DateSelector";
import { useState, useCallback } from "react";
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

interface FlashPLDashboardProps {
  onTabChange: (tab: string) => void;
  activeTab: string;
}

export function FlashPLDashboard({ onTabChange, activeTab }: FlashPLDashboardProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [panels, setPanels] = useState([
    { id: 'flashpl-metrics', component: 'flashpl-metrics' },
    { id: 'coming-soon', component: 'coming-soon' }
  ]);

  const movePanel = useCallback((dragIndex: number, hoverIndex: number) => {
    setPanels((prevPanels) => {
      const dragPanel = prevPanels[dragIndex];
      const newPanels = [...prevPanels];
      newPanels.splice(dragIndex, 1);
      newPanels.splice(hoverIndex, 0, dragPanel);
      return newPanels;
    });
  }, []);

  const renderPanel = (panel: { id: string; component: string }) => {
    switch (panel.component) {
      case 'flashpl-metrics':
        return (
          <div>
            <h2 className="mb-4 text-foreground">Flash P&L insights</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="border border-border bg-card card-glow-subtle">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium text-foreground mb-2">Net Profit</h3>
                  <p className="text-3xl font-semibold text-foreground">$45,280</p>
                  <p className="text-sm text-muted-foreground">12.8% margin</p>
                </CardContent>
              </Card>
              <Card className="border border-border bg-card card-glow-subtle">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium text-foreground mb-2">EBITDA</h3>
                  <p className="text-3xl font-semibold text-foreground">$58,750</p>
                  <p className="text-sm text-muted-foreground">16.6% margin</p>
                </CardContent>
              </Card>
              <Card className="border border-border bg-card card-glow-subtle">
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium text-foreground mb-2">Break-even</h3>
                  <p className="text-3xl font-semibold text-foreground">$8,920</p>
                  <p className="text-sm text-muted-foreground">Daily target</p>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      case 'coming-soon':
        return (
          <div className="flex items-center justify-center py-20">
            <p className="text-muted-foreground">Flash P&L dashboard content coming soon...</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex gap-4 text-sm">
            <button 
              onClick={() => onTabChange('sales')}
              className={`pb-1 ${activeTab === 'sales' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Sales
            </button>
            <button 
              onClick={() => onTabChange('cogs')}
              className={`pb-1 ${activeTab === 'cogs' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              CoGS
            </button>
            <button 
              onClick={() => onTabChange('labour')}
              className={`pb-1 ${activeTab === 'labour' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Labour
            </button>
            <button 
              onClick={() => onTabChange('flashpl')}
              className={`pb-1 ${activeTab === 'flashpl' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Flash P&L
            </button>
            <button 
              onClick={() => onTabChange('cash')}
              className={`pb-1 ${activeTab === 'cash' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Cash management
            </button>
          </div>
        </div>
        
        {/* Center - Date Selector */}
        <div className="flex-1 flex justify-center">
          <DateSelector />
        </div>
        
        <div className="w-64 relative">
          <div className="bg-card border border-border rounded-lg">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full flex items-center justify-between p-3 hover:bg-muted/30 rounded-lg transition-colors"
            >
              <span className="text-sm text-muted-foreground">All locations</span>
              <div className="flex items-center gap-1">
                <div className="w-6 h-6 bg-muted-foreground/20 rounded-full flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">4</span>
                </div>
                <svg 
                  className={`w-4 h-4 text-muted-foreground transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </button>
          </div>
            
          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50">
              <div className="p-3">
                <div className="relative mb-3">
                  <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <input 
                    type="text" 
                    placeholder="Search" 
                    className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-sm text-foreground placeholder-muted-foreground"
                  />
                </div>
                
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground mb-2">Blanchardstown</div>
                  <button className="w-full bg-primary text-primary-foreground px-3 py-2 rounded text-sm font-medium text-left">
                    Charlotte Way
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Dundrum
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    HQ
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Liffey Valley
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Millennium Walk
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Draggable Panels */}
      <div className="space-y-6">
        {panels.map((panel, index) => (
          <DraggablePanel
            key={panel.id}
            id={panel.id}
            index={index}
            movePanel={movePanel}
          >
            {renderPanel(panel)}
          </DraggablePanel>
        ))}
      </div>
    </div>
    </DndProvider>
  );
}