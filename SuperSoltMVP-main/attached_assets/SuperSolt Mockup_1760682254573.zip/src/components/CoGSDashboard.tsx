import { InventoryMetricCard } from "./InventoryMetricCard";
import { WasteChart } from "./WasteChart";
import { DraggablePanel } from "./DraggablePanel";
import { Card, CardContent } from "./ui/card";
import { DateSelector } from "./DateSelector";
import { useState, useCallback } from "react";
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

interface CoGSDashboardProps {
  onTabChange: (tab: string) => void;
  activeTab: string;
}

export function CoGSDashboard({ onTabChange, activeTab }: CoGSDashboardProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [panels, setPanels] = useState([
    { id: 'inventory-metrics', component: 'inventory-metrics' },
    { id: 'waste-chart', component: 'waste-chart' }
  ]);

  const movePanel = useCallback((dragIndex: number, hoverIndex: number) => {
    setPanels((prevPanels) => {
      const dragPanel = prevPanels[dragIndex];
      const newPanels = [...prevPanels];
      newPanels.splice(dragIndex, 1);
      newPanels.splice(hoverIndex, 0, dragPanel);
      return newPanels;
    });
  }, []);

  const renderPanel = (panel: { id: string; component: string }) => {
    switch (panel.component) {
      case 'inventory-metrics':
        return (
          <div>
            <h2 className="mb-4 text-foreground">Inventory insights</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <InventoryMetricCard
                title="Food cost %"
                value="28.5%"
                color="#8b5cf6"
                chartData={[
                  { value: 26.2 }, { value: 27.8 }, { value: 25.9 }, { value: 28.1 }, 
                  { value: 29.5 }, { value: 27.3 }, { value: 28.8 }, { value: 26.7 }, 
                  { value: 28.9 }, { value: 28.5 }
                ]}
              />
              <InventoryMetricCard
                title="Waste cost"
                value="$1,160"
                color="#ef4444"
                chartData={[
                  { value: 980 }, { value: 1120 }, { value: 890 }, { value: 1050 }, 
                  { value: 1200 }, { value: 950 }, { value: 1180 }, { value: 1080 }, 
                  { value: 1150 }, { value: 1160 }
                ]}
              />
              <InventoryMetricCard
                title="Stock value"
                value="$12,450"
                color="#10b981"
                chartData={[
                  { value: 11200 }, { value: 11800 }, { value: 12100 }, { value: 11900 }, 
                  { value: 12300 }, { value: 12050 }, { value: 12400 }, { value: 12200 }, 
                  { value: 12350 }, { value: 12450 }
                ]}
              />
            </div>

            {/* Side by side sections */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Waste breakdown */}
              <div>
                <h3 className="text-sm text-muted-foreground mb-3">Waste breakdown</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">15%</p>
                      <p className="text-sm text-muted-foreground">Waste %</p>
                    </CardContent>
                  </Card>
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">$840</p>
                      <p className="text-sm text-muted-foreground">Accounted</p>
                    </CardContent>
                  </Card>
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">$320</p>
                      <p className="text-sm text-muted-foreground">Unaccounted</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Stock management */}
              <div>
                <h3 className="text-sm text-muted-foreground mb-3">Stock management</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">92%</p>
                      <p className="text-sm text-muted-foreground">Stock accuracy</p>
                    </CardContent>
                  </Card>
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">45</p>
                      <p className="text-sm text-muted-foreground">Items ordered</p>
                    </CardContent>
                  </Card>
                  <Card className="border border-border bg-card card-glow-subtle">
                    <CardContent className="p-4 text-center">
                      <p className="text-2xl font-semibold text-foreground">3.2</p>
                      <p className="text-sm text-muted-foreground">Days stock</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );
      case 'waste-chart':
        return <WasteChart />;
      default:
        return null;
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex gap-4 text-sm">
            <button 
              onClick={() => onTabChange('sales')}
              className={`pb-1 ${activeTab === 'sales' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Sales
            </button>
            <button 
              onClick={() => onTabChange('cogs')}
              className={`pb-1 ${activeTab === 'cogs' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              CoGS
            </button>
            <button 
              onClick={() => onTabChange('labour')}
              className={`pb-1 ${activeTab === 'labour' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Labour
            </button>
            <button 
              onClick={() => onTabChange('flashpl')}
              className={`pb-1 ${activeTab === 'flashpl' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Flash P&L
            </button>
            <button 
              onClick={() => onTabChange('cash')}
              className={`pb-1 ${activeTab === 'cash' ? 'border-b-2 border-primary font-medium text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              Cash management
            </button>
          </div>
        </div>
        
        {/* Center - Date Selector */}
        <div className="flex-1 flex justify-center">
          <DateSelector />
        </div>
        
        <div className="w-64 relative">
          <div className="bg-card border border-border rounded-lg">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full flex items-center justify-between p-3 hover:bg-muted/30 rounded-lg transition-colors"
            >
              <span className="text-sm text-muted-foreground">All locations</span>
              <div className="flex items-center gap-1">
                <div className="w-6 h-6 bg-muted-foreground/20 rounded-full flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">4</span>
                </div>
                <svg 
                  className={`w-4 h-4 text-muted-foreground transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </button>
          </div>
            
          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-50">
              <div className="p-3">
                <div className="relative mb-3">
                  <svg className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <input 
                    type="text" 
                    placeholder="Search" 
                    className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-sm text-foreground placeholder-muted-foreground"
                  />
                </div>
                
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground mb-2">Blanchardstown</div>
                  <button className="w-full bg-primary text-primary-foreground px-3 py-2 rounded text-sm font-medium text-left">
                    Charlotte Way
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Dundrum
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    HQ
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Liffey Valley
                  </button>
                  <button className="w-full text-sm text-muted-foreground py-1 px-3 hover:bg-muted/50 rounded text-left transition-colors">
                    Millennium Walk
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Draggable Panels */}
      <div className="space-y-6">
        {panels.map((panel, index) => (
          <DraggablePanel
            key={panel.id}
            id={panel.id}
            index={index}
            movePanel={movePanel}
          >
            {renderPanel(panel)}
          </DraggablePanel>
        ))}
      </div>
    </div>
    </DndProvider>
  );
}