import { useState } from "react";
import { Calendar } from "./ui/calendar";
import { ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";

interface DateSelectorProps {
  className?: string;
}

export function DateSelector({ className = "" }: DateSelectorProps) {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewType, setViewType] = useState<'Weekly' | 'Daily' | 'Monthly'>('Weekly');

  const formatDateRange = (date: Date, type: string) => {
    if (type === 'Weekly') {
      const startOfWeek = new Date(date);
      const day = startOfWeek.getDay();
      const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is Sunday
      startOfWeek.setDate(diff);
      
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);
      
      const formatDate = (d: Date) => {
        return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
      };
      
      return `${formatDate(startOfWeek)} - ${formatDate(endOfWeek)}`;
    }
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(selectedDate);
    if (viewType === 'Weekly') {
      newDate.setDate(selectedDate.getDate() + (direction === 'next' ? 7 : -7));
    } else if (viewType === 'Daily') {
      newDate.setDate(selectedDate.getDate() + (direction === 'next' ? 1 : -1));
    } else if (viewType === 'Monthly') {
      newDate.setMonth(selectedDate.getMonth() + (direction === 'next' ? 1 : -1));
    }
    setSelectedDate(newDate);
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* Navigation arrows */}
      <button 
        onClick={() => navigateDate('prev')}
        className="p-1 hover:bg-muted/30 rounded text-muted-foreground hover:text-foreground transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {/* Date selector dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsCalendarOpen(!isCalendarOpen)}
          className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-muted/30 rounded transition-colors"
        >
          <span className="text-foreground font-medium">{viewType}</span>
          <ChevronDown className={`w-3 h-3 text-muted-foreground transition-transform ${isCalendarOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Calendar dropdown */}
        {isCalendarOpen && (
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-card border border-border rounded-lg shadow-lg z-50 p-4">
            {/* View type selector */}
            <div className="flex gap-1 mb-4 p-1 bg-muted/20 rounded">
              {(['Daily', 'Weekly', 'Monthly'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setViewType(type)}
                  className={`px-3 py-1 text-xs rounded transition-colors ${
                    viewType === type 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>

            {/* Calendar */}
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                if (date) {
                  setSelectedDate(date);
                  setIsCalendarOpen(false);
                }
              }}
              className="w-auto"
            />
          </div>
        )}
      </div>

      {/* Current date range */}
      <span className="text-sm text-foreground">
        {formatDateRange(selectedDate, viewType)}
      </span>

      {/* Comparison toggle */}
      <span className="text-sm text-muted-foreground mx-2">vs</span>
      <span className="text-sm text-muted-foreground">Forecast</span>

      {/* Navigation arrows */}
      <button 
        onClick={() => navigateDate('next')}
        className="p-1 hover:bg-muted/30 rounded text-muted-foreground hover:text-foreground transition-colors"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}