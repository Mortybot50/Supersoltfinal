import { Card, CardContent } from "./ui/card";

interface HorizontalMetricCardProps {
  title: string;
  value: string;
  comparison?: string;
  comparisonValue?: string;
  items?: Array<{ label: string; value: string; color: string; percentage: number }>;
  singleBar?: { color: string; percentage: number };
}

export function HorizontalMetricCard({ 
  title, 
  value, 
  comparison, 
  comparisonValue,
  items,
  singleBar 
}: HorizontalMetricCardProps) {
  return (
    <Card className="border border-border bg-card card-glow-subtle">
      <CardContent className="p-4">
        <p className="text-sm text-muted-foreground mb-2">{title}</p>
        <div className="flex items-center gap-2 mb-3">
          <p className="text-2xl font-semibold text-foreground">{value}</p>
          {comparison && comparisonValue && (
            <div className="flex items-center gap-1">
              <span className="text-xs text-primary">{comparisonValue}</span>
              <span className="text-xs text-muted-foreground">{comparison}</span>
            </div>
          )}
        </div>
        
        {items && items.length > 0 && (
          <div className="space-y-2">
            {items.map((item, index) => (
              <div key={index}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-2 h-2 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-xs text-muted-foreground">{item.label}</span>
                  </div>
                  <span className="text-xs text-foreground">{item.value}</span>
                </div>
                <div className="w-full h-2 bg-muted/20 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-300"
                    style={{ 
                      width: `${item.percentage}%`,
                      backgroundColor: item.color
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
        
        {singleBar && (
          <div className="w-full h-2 bg-muted/20 rounded-full overflow-hidden">
            <div 
              className="h-full rounded-full transition-all duration-300"
              style={{ 
                width: `${singleBar.percentage}%`,
                backgroundColor: singleBar.color
              }}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
