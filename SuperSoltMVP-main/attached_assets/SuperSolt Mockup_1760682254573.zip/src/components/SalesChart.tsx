import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from 'recharts';
import { useState } from 'react';

const salesChartData = [
  { day: 'Mon 22', actual: 7200, forecast: 6800, fullDate: 'Mon 22 Apr' },
  { day: 'Tue 23', actual: 8100, forecast: 7900, fullDate: 'Tue 23 Apr' },
  { day: 'Wed 24', actual: 10500, forecast: 10200, fullDate: 'Wed 24 Apr' },
  { day: 'Thu 25', actual: 14200, forecast: 13800, fullDate: 'Thu 25 Apr' },
  { day: 'Fri 26', actual: 19800, forecast: 20500, fullDate: 'Fri 26 Apr' },
  { day: 'Sat 27', actual: 17200, forecast: 18100, fullDate: 'Sat 27 Apr' },
  { day: 'Sun 28', actual: 16800, forecast: 17200, fullDate: 'Sun 28 Apr' }
];

const ordersChartData = [
  { day: 'Mon 22', actual: 245, forecast: 220, fullDate: 'Mon 22 Apr' },
  { day: 'Tue 23', actual: 298, forecast: 280, fullDate: 'Tue 23 Apr' },
  { day: 'Wed 24', actual: 385, forecast: 370, fullDate: 'Wed 24 Apr' },
  { day: 'Thu 25', actual: 520, forecast: 495, fullDate: 'Thu 25 Apr' },
  { day: 'Fri 26', actual: 680, forecast: 720, fullDate: 'Fri 26 Apr' },
  { day: 'Sat 27', actual: 625, forecast: 650, fullDate: 'Sat 27 Apr' },
  { day: 'Sun 28', actual: 580, forecast: 610, fullDate: 'Sun 28 Apr' }
];

const productsChartData = [
  { day: 'Mon 22', actual: 8500, forecast: 9200, fullDate: 'Mon 22 Apr' },
  { day: 'Tue 23', actual: 9800, forecast: 10100, fullDate: 'Tue 23 Apr' },
  { day: 'Wed 24', actual: 12200, forecast: 12800, fullDate: 'Wed 24 Apr' },
  { day: 'Thu 25', actual: 17500, forecast: 18200, fullDate: 'Thu 25 Apr' },
  { day: 'Fri 26', actual: 21500, forecast: 22800, fullDate: 'Fri 26 Apr' },
  { day: 'Sat 27', actual: 19800, forecast: 21200, fullDate: 'Sat 27 Apr' },
  { day: 'Sun 28', actual: 18200, forecast: 19600, fullDate: 'Sun 28 Apr' }
];

// Custom Tooltip Component
const CustomTooltip = ({ active, payload, label, viewType }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const isOrders = viewType === 'orders';
    return (
      <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
        <p className="text-foreground font-medium mb-2">{data.fullDate}</p>
        <div className="space-y-1">
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">{isOrders ? 'Orders:' : 'Sales:'}</span>
            <span className="text-foreground font-medium">
              {isOrders ? data.actual.toLocaleString() : `${data.actual.toLocaleString()}`}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-muted-foreground text-sm">Forecast (day):</span>
            <span className="text-muted-foreground">
              {isOrders ? data.forecast.toLocaleString() : `${data.forecast.toLocaleString()}`}
            </span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const salesData = [
  { metric: 'Total Sales', actual: '$111,076', change: '+2%', forecast: '$114,500' },
  { metric: 'Dine In', actual: '$77,550', change: '+4.8%', forecast: '$81,525' },
  { metric: 'Pick-up', actual: '$5,173', change: '+24.8%', forecast: '$6,254' },
  { metric: 'Delivery', actual: '$28,353', change: '+1.4%', forecast: '$28,722' }
];

const ordersData = [
  { metric: 'Total Orders', actual: '3,333', change: '+2.5%', forecast: '3,545' },
  { metric: 'Dine In', actual: '2,105', change: '+3.2%', forecast: '2,280' },
  { metric: 'Pick-up', actual: '288', change: '+18.5%', forecast: '320' },
  { metric: 'Delivery', actual: '940', change: '-1.8%', forecast: '945' }
];

const productsData = [
  { name: 'Tailor Tots', qtySold: 673, value: '$2,885.83', salesPercent: '2.59%' },
  { name: 'Loaded Fries', qtySold: 473, value: '$2,682.52', salesPercent: '2.58%' },
  { name: 'Onion Rings', qtySold: 471, value: '$2,505.16', salesPercent: '2.56%' },
  { name: 'Nashville Tenders', qtySold: 266, value: '$2,756.25', salesPercent: '2.46%' },
  { name: 'DIY Cheesecake', qtySold: 329, value: '$2,556.33', salesPercent: '2.25%' },
  { name: 'Coca Cola', qtySold: 896, value: '$2,456.06', salesPercent: '2.23%' },
  { name: 'Mac N Cheese with Bacon', qtySold: 435, value: '$2,470.80', salesPercent: '2.11%' },
  { name: 'Coke Zero', qtySold: 657, value: '$2,321.70', salesPercent: '2.06%' },
  { name: 'Crack Tots', qtySold: 309, value: '$2,216.66', salesPercent: '1.96%' },
  { name: 'Chicken Salt Fries', qtySold: 548, value: '$2,043.20', salesPercent: '1.91%' },
  { name: 'Tenders with 2 Dips', qtySold: 161, value: '$1,737.00', salesPercent: '1.66%' },
  { name: 'BBQ Wings', qtySold: 298, value: '$1,685.45', salesPercent: '1.52%' },
  { name: 'Hot Wings', qtySold: 287, value: '$1,624.30', salesPercent: '1.48%' },
  { name: 'Sprite', qtySold: 445, value: '$1,556.75', salesPercent: '1.41%' },
  { name: 'Buffalo Wings', qtySold: 245, value: '$1,425.80', salesPercent: '1.29%' },
  { name: 'Diet Coke', qtySold: 398, value: '$1,392.30', salesPercent: '1.26%' },
  { name: 'Fanta Orange', qtySold: 356, value: '$1,246.60', salesPercent: '1.13%' },
  { name: 'Plain Tots', qtySold: 287, value: '$1,204.50', salesPercent: '1.09%' },
  { name: 'Garlic Aioli Fries', qtySold: 234, value: '$1,156.75', salesPercent: '1.05%' },
  { name: 'Water Bottle', qtySold: 892, value: '$1,124.80', salesPercent: '1.02%' }
];

// Custom Bar with Outline
const CustomBar = ({ fill, payload, ...props }: any) => {
  const isforecast = props.dataKey === 'forecast';
  if (isforecast) {
    return (
      <Bar
        {...props}
        fill="rgba(182, 254, 154, 0.15)"
        stroke="#b6fe9a"
        strokeWidth={1.5}
        radius={[2, 2, 0, 0]}
      />
    );
  }
  return <Bar {...props} fill={fill} radius={[2, 2, 0, 0]} />;
};

export function SalesChart() {
  const [activeView, setActiveView] = useState<'sales' | 'orders' | 'products'>('sales');
  
  const currentChartData = activeView === 'products' ? productsChartData :
                          activeView === 'orders' ? ordersChartData : salesChartData;
  const currentTableData = activeView === 'orders' ? ordersData : salesData;
  const currentTitle = activeView === 'products' ? 'Products 22-28 April' : 
                      activeView === 'orders' ? 'Orders v Forecast 22-28 April' : 'Sales v Forecast 22-28 April';
  const currentMetricTitle = activeView === 'products' ? 'Products' :
                            activeView === 'orders' ? 'Orders' : 'Sales';
                            
  // Colors for different views
  const getBarColors = () => {
    if (activeView === 'products') {
      return {
        actual: '#22d3ee', // cyan-400
        forecast: 'rgba(34, 211, 238, 0.15)',
        forecastStroke: '#22d3ee'
      };
    }
    return {
      actual: '#b6fe9a',
      forecast: 'rgba(182, 254, 154, 0.15)',
      forecastStroke: '#b6fe9a'
    };
  };

  return (
    <div className="space-y-6">
      <Card className="border border-border bg-card card-glow-subtle">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div>
              <h3 className="text-foreground">{currentTitle}</h3>
              <p className="text-sm text-muted-foreground mt-1">Show month</p>
            </div>
            <div className="flex gap-4 text-sm">
              <button
                onClick={() => setActiveView('sales')}
                className={`pb-1 transition-all ${
                  activeView === 'sales'
                    ? 'border-b-2 border-primary text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Sales
              </button>
              <button
                onClick={() => setActiveView('orders')}
                className={`pb-1 transition-all ${
                  activeView === 'orders'
                    ? 'border-b-2 border-primary text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Orders
              </button>
              <button
                onClick={() => setActiveView('products')}
                className={`pb-1 transition-all ${
                  activeView === 'products'
                    ? 'border-b-2 border-primary text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Products
              </button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={currentChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip viewType={activeView} />} cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }} />
                <Bar dataKey="actual" fill={getBarColors().actual} radius={[2, 2, 0, 0]} />
                <Bar 
                  dataKey="forecast" 
                  fill={getBarColors().forecast}
                  stroke={getBarColors().forecastStroke}
                  strokeWidth={1.5} 
                  radius={[2, 2, 0, 0]} 
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          {activeView === 'products' ? (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-foreground">Product name</h4>
                <div className="flex gap-6 text-sm text-muted-foreground">
                  <span className="w-16 text-right">Qty sold</span>
                  <span className="w-20 text-right">Value</span>
                  <span className="w-16 text-right">% of sales</span>
                </div>
              </div>
              <div className="h-48 overflow-y-auto space-y-1 pr-2">
                {productsData.map((product, index) => (
                  <div key={index} className="flex justify-between items-center py-2 px-3 hover:bg-muted/20 rounded-md transition-colors">
                    <span className="text-foreground">{product.name}</span>
                    <div className="flex gap-6 text-sm">
                      <span className="text-foreground w-16 text-right">{product.qtySold}</span>
                      <span className="text-foreground w-20 text-right">{product.value}</span>
                      <span className="text-muted-foreground w-16 text-right">{product.salesPercent}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-foreground">{currentMetricTitle}</h4>
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{backgroundColor: getBarColors().actual}}></div>
                    <span className="text-foreground">Actual</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full border" 
                      style={{
                        backgroundColor: getBarColors().forecast,
                        borderColor: getBarColors().forecastStroke,
                        borderWidth: '1.5px'
                      }}
                    ></div>
                    <span className="text-foreground">Forecast</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                {currentTableData.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2">
                    <span className="text-muted-foreground">{item.metric}</span>
                    <div className="flex gap-8 text-right">
                      <div>
                        <span className="font-medium text-foreground">{item.actual}</span>
                        <span className={`text-sm ml-2 ${
                          item.change.startsWith('+') ? 'text-primary' : 'text-destructive'
                        }`}>{item.change}</span>
                      </div>
                      <span className="text-muted-foreground w-20">{item.forecast}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}